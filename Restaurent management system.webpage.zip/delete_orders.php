    <?php
include("connection/connect.php"); //connection to db
error_reporting(0);
session_start();


// sending query
$sql=mysqli_query($db,"update invoice set status='rejected' where invoice_id='".$_GET['order_status']."'");
header("location:your_orders.php"); 

?>
    