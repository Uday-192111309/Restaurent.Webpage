<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

    <link rel='stylesheet prefetch'
        href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/login.css">

    <style type="text/css">
    #buttn {
        color: #fff;
        background-color: #5c4ac7;
    }

    .form-style {
        position: relative;
        */ background: #ffffff;
        width: 100%;
        border-top: 5px solid #5c4ac7;
        box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
        margin: 0 auto;
    }
    </style>



    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>


<body>
<?php include("include/navbar.php");  ?>
    <div style=" background-image: url('images/img/pimg.jpg');">

    <?php
include("connection/connect.php"); // Ensure this includes your database connection script

$message = ""; 

if(isset($_POST['submit'])) {
    $fullName = $_POST['fullName'];  
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $messageText = $_POST['message'];

    // Validation to check for empty fields
    if(empty($fullName) || empty($email) || empty($subject) || empty($messageText)) {
        $message = "All fields are required!";
    }else if(!is_numeric($phone) || strlen($phone) != 10) {
        $message = "Please enter a valid 10-digit phone number!";
    }  else {
        // Insert into database
        $insertQuery = "INSERT INTO enquiries (fullName, email, phone, subject, message) VALUES ('$fullName', '$email', '$phone', '$subject', '$messageText')";
        $result = mysqli_query($db, $insertQuery);

        if($result) {
            $message = "Enquiry submitted successfully!";
        } else {
            $message = "Error submitting enquiry. Please try again.";
        }
    }
}
?>



        <div class="pen-title">
        </div>

        <div class="container mt-5 bg-white" style="margin: 0 auto;">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <h2 class="mb-4">Contact Us</h2>

                    <!-- Display PHP messages based on backend processing -->
                    <?php if(!empty($message)): ?>
                        <div class="alert alert-<?php echo isset($result) && $result ? 'success' : 'danger'; ?>" role="alert">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Contact form -->
                    <form action="" method="post">
                        <!-- Personal Information -->
                        <div class="form-group">
                            <label for="fullName">Full Name:</label>
                            <input type="text" class="form-control" id="fullName" name="fullName"
                                placeholder="Enter your full name" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email"
                                placeholder="Enter your email address" required>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone Number:</label>
                            <input type="tel" class="form-control" id="phone" name="phone" maxlength="10"
                                placeholder="Enter your phone number">
                        </div>

                        <!-- Subject of Inquiry -->
                        <div class="form-group">
                            <label for="subject">Subject of Inquiry:</label>
                            <select class="form-control" id="subject" name="subject">
                                <option value="General Inquiry">General Inquiry</option>
                                <option value="Feedback">Feedback</option>
                                <option value="Order Issue">Order Issue</option>
                                <option value="Technical Support">Technical Support</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>

                        <!-- Message or Feedback -->
                        <div class="form-group">
                            <label for="message">Message or Feedback:</label>
                            <textarea class="form-control" id="message" name="message" rows="5"
                                placeholder="Type your message here..." required></textarea>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" name="submit" class="btn btn-primary">Submit Inquiry</button>
                    </form>
                </div>
            </div>

            <!-- Additional Information or Links -->
            <div class="row mt-4">
                <div class="col-md-6 offset-md-3 text-center">
                    For other inquiries, feel free to email us directly at <a href="mailto:info@example.com"
                        class="text-primary">info@example.com</a>.
                </div>
            </div>
        </div>


        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>





        <div class="container-fluid pt-3">
            <p></p>
        </div>



        <?php include "include/footer.php" ?>




</body>

</html>