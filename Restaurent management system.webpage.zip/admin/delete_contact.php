              
                <?php
include("../connection/connect.php");
error_reporting(0);
session_start();

mysqli_query($db,"DELETE FROM enquiries WHERE id = '".$_GET['enquiry_del']."'");
header("location:all_enquires.php");  

?>
                