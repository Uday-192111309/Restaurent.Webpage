 <footer class="footer" style="text-align: center;">codelone.com © 2023 - Online Food Ordering System</footer>
